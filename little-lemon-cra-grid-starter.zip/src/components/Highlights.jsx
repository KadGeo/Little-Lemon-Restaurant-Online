import React from 'react';

export default function Highlights() {
  return (
    <section id="highlights" className="highlights">
      <h2 className="section-title">Today’s Special</h2>

      <div className="special">
        <figure className="special__image">
          <img
            src="https://images.unsplash.com/photo-1559056199-641a0ac8b55e?q=80&w=1200&auto=format&fit=crop"
            alt="Grilled Sea Bass with Citrus Couscous"
          />
        </figure>

        <div className="special__details">
          <h3>Grilled Sea Bass &amp; Citrus Couscous</h3>
          <p className="muted">
            Fresh sea bass with olive oil and herbs, served with lemon-infused
            couscous and seasonal vegetables.
          </p>
          <p className="price">$19.95</p>
        </div>
      </div>
    </section>
  );
}
