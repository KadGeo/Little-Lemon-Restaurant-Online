import React from 'react';

export default function Navbar() {
  return (
    <header className="navbar">
      <nav className="navbar__inner" aria-label="Main">
        <a className="brand" href="#hero" aria-label="Little Lemon home">
          Little Lemon
        </a>
        <ul className="navlinks">
          <li><a href="#hero">Home</a></li>
          <li><a href="#highlights">Menu</a></li>
          <li><a href="#highlights">Reservations</a></li>
          <li><a href="#testimonials">Order Online</a></li>
          <li><a href="#about">Login</a></li>
        </ul>
      </nav>
    </header>
  );
}
